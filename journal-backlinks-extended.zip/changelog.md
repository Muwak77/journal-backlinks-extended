
markdown
Copy code
# Changelog

## Version 0.12.4
- Added compatibility for Journal Anchor Links

## Version 0.12.5


- When a journal page is linked, it now receives an anchor link in the journal entry's sidebar navigation. This link points directly to the "Backlinks" section of the page.

- Added an option to choose whether links from journal pages display only the page name or both the journal and page names.

- An error-message in the console was suspended that appered, when journal categories war not installed






