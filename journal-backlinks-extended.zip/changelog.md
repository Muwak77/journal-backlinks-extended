#Version 0.12.4
Added compatibility for Journal Anchor Links